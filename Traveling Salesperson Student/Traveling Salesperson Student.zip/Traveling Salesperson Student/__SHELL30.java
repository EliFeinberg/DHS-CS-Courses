
public class __SHELL30 extends bluej.runtime.Shell {
public static void run() throws Throwable {

java.lang.String[] __bluej_param0 = { };
TSPClientDriver.main(__bluej_param0);

}}
