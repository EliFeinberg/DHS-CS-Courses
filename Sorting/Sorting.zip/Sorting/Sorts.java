import java.util.ArrayList;
/**
 * This Sorts object represents a class that perform
 * Bubble, Selection, Insertion, Merge, Quick, and Heap sorts
 * 
 * @author  
 * @version 
 */
public class Sorts extends SortUtilities
{

    public Sorts(String[] array)
    {
        super(array);
    }

    // The array to be sorted is a String array called 'array'

    // Whenever you need to swap two elements in 'array', call the 'swap(int a, int b)' method 
    // where a and b are the indices of the elements in 'array' that need to be swapped.  Every
    // time 'swap' is called, a snapshot of the array is taken, which is later used to 
    // compare against an exemplar (test example) to see if all of the swaps are correct.

    // All of your sorting methods should utilize 'in-place' sorting, meaning that elements
    // are always swapped, rather than being copied out to a temporary variable, and then copied 
    // back later.

    // Feel free to write any private helper methods you wish to use

    public void bubbleSort()    // ascending, bubbling up from beginning to end
    {
    }

    public void selectionSort() // ascending, selecting the maximum values
    {
    }

    public void insertionSort() // ascending, inserting values on the front end
    {
    }

    public void mergeSort() // ascending, working from front to back
    {
    }

    public void quickSort() // ascending, working from front to back
    {
    }

    public void heapSort()  // ascending
    {
        // Note that the 'reheapDown' and 'newHole' methods are already provided
        // in the abstract parent class (SortUtilities) for your use.
    }

}
