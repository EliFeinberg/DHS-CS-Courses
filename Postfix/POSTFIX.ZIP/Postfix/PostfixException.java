public class PostfixException extends Exception
{
    public PostfixException()
    {
        super();
    }
    
    public PostfixException(String message)
    {
        super(message);
    }
}
